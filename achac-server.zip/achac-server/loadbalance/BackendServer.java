package loadbalance;

import java.net.*;
import java.util.concurrent.atomic.*;

public class BackendServer {
    private String host;
    private int port;
    private AtomicInteger activeConnections;
    private AtomicBoolean healthy;
    private long lastHealthCheck;
    private int weight;
    
    public BackendServer(String host, int port) {
        this(host, port, 1);
    }
    
    public BackendServer(String host, int port, int weight) {
        this.host = host;
        this.port = port;
        this.weight = weight;
        this.activeConnections = new AtomicInteger(0);
        this.healthy = new AtomicBoolean(true);
        this.lastHealthCheck = System.currentTimeMillis();
    }
    
    public String getHost() {
        return host;
    }
    
    public int getPort() {
        return port;
    }
    
    public int getWeight() {
        return weight;
    }
    
    public int getActiveConnections() {
        return activeConnections.get();
    }
    
    public void incrementConnections() {
        activeConnections.incrementAndGet();
    }
    
    public void decrementConnections() {
        activeConnections.decrementAndGet();
    }
    
    public boolean isHealthy() {
        // 如果超过30秒没有健康检查，重新检查
        if (System.currentTimeMillis() - lastHealthCheck > 30000) {
            checkHealth();
        }
        return healthy.get();
    }
    
    public void checkHealth() {
        lastHealthCheck = System.currentTimeMillis();
        
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 2000);
            healthy.set(true);
        } catch (Exception e) {
            healthy.set(false);
            System.err.println("[BackendServer] Health check failed: " + this);
        }
    }
    
    public void setHealthy(boolean healthy) {
        this.healthy.set(healthy);
    }
    
    public String getUrl() {
        return "http://" + host + ":" + port;
    }
    
    @Override
    public String toString() {
        return String.format("%s:%d (weight=%d, connections=%d, healthy=%s)", 
                            host, port, weight, activeConnections.get(), healthy.get());
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        BackendServer that = (BackendServer) obj;
        return port == that.port && host.equals(that.host);
    }
    
    @Override
    public int hashCode() {
        return 31 * host.hashCode() + port;
    }
}