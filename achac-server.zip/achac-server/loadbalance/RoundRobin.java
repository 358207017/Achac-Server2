package loadbalance;

import loadbalance.BackendServer;
import loadbalance.LoadBalancer;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class RoundRobin extends LoadBalancer {
    private AtomicInteger counter;
    
    public RoundRobin() {
        super();
        this.counter = new AtomicInteger(0);
    }
    
    @Override
    public BackendServer getNextServer(String clientIp, String path) {
        List<BackendServer> healthyServers = getHealthyServers();
        
        if (healthyServers.isEmpty()) {
            return null;
        }
        
        int index = Math.abs(counter.getAndIncrement() % healthyServers.size());
        return healthyServers.get(index);
    }
    
    public void reset() {
        counter.set(0);
    }
}