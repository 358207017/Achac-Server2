package loadbalance;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public abstract class LoadBalancer {
    protected List<BackendServer> servers;
    protected AtomicInteger currentIndex;
    
    public LoadBalancer() {
        this.servers = new CopyOnWriteArrayList<>();
        this.currentIndex = new AtomicInteger(0);
    }
    
    public void addServer(BackendServer server) {
        servers.add(server);
        System.out.println("[LoadBalancer] Added server: " + server);
    }
    
    public void removeServer(BackendServer server) {
        servers.remove(server);
        System.out.println("[LoadBalancer] Removed server: " + server);
    }
    
    public void removeServer(String host, int port) {
        servers.removeIf(s -> s.getHost().equals(host) && s.getPort() == port);
    }
    
    public List<BackendServer> getHealthyServers() {
        List<BackendServer> healthy = new ArrayList<>();
        for (BackendServer server : servers) {
            if (server.isHealthy()) {
                healthy.add(server);
            }
        }
        return healthy;
    }
    
    public abstract BackendServer getNextServer(String clientIp, String path);
    
    public int getServerCount() {
        return servers.size();
    }
    
    public void healthCheck() {
        for (BackendServer server : servers) {
            server.checkHealth();
        }
    }
}