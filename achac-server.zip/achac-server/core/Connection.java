package core;

import handler.RequestHandler;
import security.DefenseWall;
import config.ServerConfig;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;

public class Connection {
    private SocketChannel channel;
    private String clientIp;
    private DefenseWall defenseWall;
    private ByteBuffer readBuffer;
    private ByteBuffer writeBuffer;
    private StringBuilder requestBuilder;
    private boolean readingHeaders;
    private int contentLength;
    private long lastActivityTime;
    
    public Connection(SocketChannel channel, String clientIp, DefenseWall defenseWall) {
        this.channel = channel;
        this.clientIp = clientIp;
        this.defenseWall = defenseWall;
        this.readBuffer = ByteBuffer.allocate(8192);
        this.writeBuffer = ByteBuffer.allocate(65536);
        this.requestBuilder = new StringBuilder();
        this.readingHeaders = true;
        this.contentLength = 0;
        this.lastActivityTime = System.currentTimeMillis();
    }
    
    public boolean handleRead(SelectionKey key) throws IOException {
        lastActivityTime = System.currentTimeMillis();
        int bytesRead = channel.read(readBuffer);
        
        if (bytesRead == -1) {
            close();
            return false;
        }
        
        readBuffer.flip();
        byte[] data = new byte[readBuffer.remaining()];
        readBuffer.get(data);
        readBuffer.clear();
        
        String requestData = new String(data);
        requestBuilder.append(requestData);
        
        if (readingHeaders && requestBuilder.toString().contains("\r\n\r\n")) {
            readingHeaders = false;
            String request = requestBuilder.toString();
            String[] lines = request.split("\r\n");
            
            if (lines.length > 0) {
                String[] requestLine = lines[0].split(" ");
                if (requestLine.length >= 2) {
                    String method = requestLine[0];
                    String path = requestLine[1];
                    
                    String userAgent = "";
                    for (String line : lines) {
                        if (line.toLowerCase().startsWith("user-agent:")) {
                            userAgent = line.substring(12).trim();
                            break;
                        }
                    }
                    
                    if (defenseWall != null && !defenseWall.checkRequest(clientIp, path, userAgent)) {
                        String blockResponse = defenseWall.getBlockResponse();
                        writeBuffer.put(blockResponse.getBytes());
                        writeBuffer.flip();
                        return true;
                    }
                    
                    String response = RequestHandler.handle(method, path, 
                                        ServerConfig.getInstance().getStaticRoot(), defenseWall, clientIp);
                    writeBuffer.put(response.getBytes());
                    writeBuffer.flip();
                    
                    while (writeBuffer.hasRemaining()) {
                        channel.write(writeBuffer);
                    }
                    
                    if (request.contains("Connection: keep-alive")) {
                        reset();
                        return false;
                    } else {
                        close();
                        return false;
                    }
                }
            }
        }
        
        return false;
    }
    
    public boolean handleWrite(SelectionKey key) throws IOException {
        if (writeBuffer.hasRemaining()) {
            channel.write(writeBuffer);
        }
        
        if (!writeBuffer.hasRemaining()) {
            writeBuffer.clear();
            return true;
        }
        return false;
    }
    
    private void reset() {
        requestBuilder = new StringBuilder();
        readingHeaders = true;
        contentLength = 0;
        readBuffer.clear();
        writeBuffer.clear();
    }
    
    public void close() throws IOException {
        if (defenseWall != null) {
            defenseWall.decrementConnection(clientIp);
        }
        if (channel != null && channel.isOpen()) {
            channel.close();
        }
    }
    
    public long getLastActivityTime() {
        return lastActivityTime;
    }
}