package core;

import config.ServerConfig;
import security.DefenseWall;
import java.io.*;
import java.net.*;
import java.nio.channels.*;
import java.util.Iterator;

public class Worker extends Thread {
    private int id;
    private ServerConfig config;
    private DefenseWall defenseWall;
    private Selector selector;
    private ServerSocketChannel serverChannel;
    private volatile boolean running;
    
    public Worker(int id, ServerConfig config, DefenseWall defenseWall) {
        this.id = id;
        this.config = config;
        this.defenseWall = defenseWall;
        this.running = true;
    }
    
    public void run() {
        try {
            selector = Selector.open();
            serverChannel = ServerSocketChannel.open();
            serverChannel.configureBlocking(false);
            serverChannel.socket().bind(new InetSocketAddress(config.getPort()));
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);
            
            System.out.println("Worker " + id + " listening on port " + config.getPort());
            
            while (running) {
                selector.select(1000);
                Iterator<SelectionKey> keys = selector.selectedKeys().iterator();
                
                while (keys.hasNext()) {
                    SelectionKey key = keys.next();
                    keys.remove();
                    
                    if (!key.isValid()) continue;
                    
                    if (key.isAcceptable()) {
                        acceptConnection(key);
                    } else if (key.isReadable()) {
                        handleRead(key);
                    }
                }
            }
            
            selector.close();
        } catch (Exception e) {
            System.err.println("Worker " + id + " error: " + e.getMessage());
        }
    }
    
    private void acceptConnection(SelectionKey key) throws IOException {
        ServerSocketChannel server = (ServerSocketChannel) key.channel();
        SocketChannel client = server.accept();
        client.configureBlocking(false);
        
        String clientIp = client.socket().getInetAddress().getHostAddress();
        
        if (!defenseWall.isAllowed(clientIp)) {
            client.close();
            return;
        }
        
        Connection connection = new Connection(client, clientIp, defenseWall);
        client.register(selector, SelectionKey.OP_READ, connection);
        defenseWall.incrementConnection(clientIp);
    }
    
    private void handleRead(SelectionKey key) throws IOException {
        Connection conn = (Connection) key.attachment();
        if (conn.handleRead(key)) {
            key.interestOps(SelectionKey.OP_WRITE);
        }
    }
    
    public void shutdown() {
        running = false;
        try {
            if (selector != null) selector.wakeup();
        } catch (Exception e) {}
    }
}