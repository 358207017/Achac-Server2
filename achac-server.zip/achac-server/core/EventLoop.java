package core;

import java.io.IOException;
import java.net.StandardSocketOptions;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class EventLoop implements Runnable {
    private final int id;
    private Selector selector;
    private final ExecutorService taskExecutor;
    private final AtomicBoolean running;
    private final BlockingQueue<Runnable> taskQueue;
    private final ConcurrentHashMap<SocketChannel, Connection> connections;
    private long lastStatsTime;
    private int eventsProcessed;
    private int tasksProcessed;
    
    public EventLoop(int id) {
        this.id = id;
        this.running = new AtomicBoolean(true);
        this.taskQueue = new LinkedBlockingQueue<>();
        this.connections = new ConcurrentHashMap<>();
        this.taskExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "EventLoop-Worker-" + id);
            t.setDaemon(true);
            return t;
        });
        this.lastStatsTime = System.currentTimeMillis();
        this.eventsProcessed = 0;
        this.tasksProcessed = 0;
        
        try {
            this.selector = Selector.open();
        } catch (IOException e) {
            throw new RuntimeException("Failed to create selector for EventLoop " + id, e);
        }
    }
    
    public void run() {
        System.out.println("[EventLoop-" + id + "] Started");
        
        while (running.get()) {
            try {
                processPendingTasks();
                int readyChannels = selector.select(50);
                if (readyChannels > 0) {
                    processSelectedKeys();
                }
                cleanupTimeoutConnections();
                printStats();
            } catch (IOException e) {
                if (running.get()) {
                    System.err.println("[EventLoop-" + id + "] Error: " + e.getMessage());
                }
            } catch (Exception e) {
                System.err.println("[EventLoop-" + id + "] Unexpected error: " + e.getMessage());
            }
        }
        
        cleanup();
        System.out.println("[EventLoop-" + id + "] Stopped");
    }
    
    private void processSelectedKeys() throws IOException {
        Iterator<SelectionKey> keyIterator = selector.selectedKeys().iterator();
        while (keyIterator.hasNext()) {
            SelectionKey key = keyIterator.next();
            keyIterator.remove();
            eventsProcessed++;
            if (!key.isValid()) continue;
            try {
                if (key.isAcceptable()) {
                    handleAccept(key);
                } else if (key.isReadable()) {
                    handleRead(key);
                } else if (key.isWritable()) {
                    handleWrite(key);
                } else if (key.isConnectable()) {
                    handleConnect(key);
                }
            } catch (IOException e) {
                closeConnection(key);
            }
        }
    }
    
    private void handleAccept(SelectionKey key) throws IOException {
        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
        SocketChannel clientChannel = serverChannel.accept();
        if (clientChannel != null) {
            clientChannel.configureBlocking(false);
            clientChannel.setOption(StandardSocketOptions.TCP_NODELAY, true);
            clientChannel.setOption(StandardSocketOptions.SO_KEEPALIVE, true);
            String clientIp = clientChannel.socket().getInetAddress().getHostAddress();
            Connection connection = new Connection(clientChannel, clientIp, null);
            connections.put(clientChannel, connection);
            clientChannel.register(selector, SelectionKey.OP_READ, connection);
        }
    }
    
    private void handleRead(SelectionKey key) throws IOException {
        SocketChannel clientChannel = (SocketChannel) key.channel();
        Connection connection = (Connection) key.attachment();
        if (connection == null) {
            closeConnection(key);
            return;
        }
        try {
            boolean shouldKeepAlive = connection.handleRead(key);
            if (!shouldKeepAlive) {
                closeConnection(key);
            } else {
                key.interestOps(SelectionKey.OP_READ);
            }
        } catch (IOException e) {
            closeConnection(key);
        }
    }
    
    private void handleWrite(SelectionKey key) throws IOException {
        SocketChannel clientChannel = (SocketChannel) key.channel();
        Connection connection = (Connection) key.attachment();
        if (connection == null) {
            closeConnection(key);
            return;
        }
        try {
            boolean finished = connection.handleWrite(key);
            if (finished) {
                key.interestOps(SelectionKey.OP_READ);
            } else {
                key.interestOps(SelectionKey.OP_WRITE);
            }
        } catch (IOException e) {
            closeConnection(key);
        }
    }
    
    private void handleConnect(SelectionKey key) throws IOException {
        SocketChannel channel = (SocketChannel) key.channel();
        try {
            if (channel.finishConnect()) {
                key.interestOps(SelectionKey.OP_READ);
            } else {
                closeConnection(key);
            }
        } catch (IOException e) {
            closeConnection(key);
        }
    }
    
    private void closeConnection(SelectionKey key) {
        try {
            SocketChannel channel = (SocketChannel) key.channel();
            Connection connection = (Connection) key.attachment();
            if (connection != null) connection.close();
            connections.remove(channel);
            key.cancel();
            channel.close();
        } catch (IOException e) {}
    }
    
    private void processPendingTasks() {
        Runnable task;
        int processed = 0;
        while (processed < 100 && (task = taskQueue.poll()) != null) {
            try {
                task.run();
                tasksProcessed++;
                processed++;
            } catch (Exception e) {}
        }
    }
    
    private void cleanupTimeoutConnections() {
        long now = System.currentTimeMillis();
        long timeout = 30000;
        connections.values().removeIf(conn -> {
            if (now - conn.getLastActivityTime() > timeout) {
                try { conn.close(); return true; } catch (Exception e) { return true; }
            }
            return false;
        });
    }
    
    private void printStats() {
        long now = System.currentTimeMillis();
        if (now - lastStatsTime > 30000) {
            System.out.printf("[EventLoop-%d] Stats - Connections: %d, Events: %d, Tasks: %d%n",
                             id, connections.size(), eventsProcessed, tasksProcessed);
            lastStatsTime = now;
            eventsProcessed = 0;
            tasksProcessed = 0;
        }
    }
    
    private void cleanup() {
        try {
            for (Connection conn : connections.values()) {
                try { conn.close(); } catch (Exception e) {}
            }
            connections.clear();
            if (selector != null) selector.close();
            taskExecutor.shutdown();
        } catch (Exception e) {}
    }
    
    public void registerServerChannel(ServerSocketChannel serverChannel) throws IOException {
        serverChannel.configureBlocking(false);
        serverChannel.register(selector, SelectionKey.OP_ACCEPT);
    }
    
    public void submitTask(Runnable task) {
        if (task != null) {
            taskQueue.offer(task);
            selector.wakeup();
        }
    }
    
    public void stop() {
        running.set(false);
        selector.wakeup();
    }
    
    public int getId() { return id; }
    public int getActiveConnections() { return connections.size(); }
}