package core;

import config.ServerConfig;
import security.DefenseWall;
import java.util.ArrayList;
import java.util.List;

public class Master {
    private int workerCount;
    private List<Worker> workers;
    private ServerConfig config;
    private DefenseWall defenseWall;
    private volatile boolean running;
    
    public Master(int workerCount, ServerConfig config, DefenseWall defenseWall) {
        this.workerCount = workerCount;
        this.config = config;
        this.defenseWall = defenseWall;
        this.workers = new ArrayList<>();
        this.running = true;
    }
    
    public void start() {
        for (int i = 0; i < workerCount; i++) {
            Worker worker = new Worker(i, config, defenseWall);
            workers.add(worker);
            worker.start();
            System.out.println("✓ Worker " + i + " started");
        }
    }
    
    public void stop() {
        running = false;
        for (Worker worker : workers) {
            worker.shutdown();
        }
    }
}