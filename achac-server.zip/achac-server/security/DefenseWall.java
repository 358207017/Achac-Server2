package security;

import config.ServerConfig;
import java.util.concurrent.*;
import java.util.*;
import java.time.*;

public class DefenseWall {
    private static DefenseWall instance;
    private ServerConfig config;
    
    // IP连接数统计
    private ConcurrentHashMap<String, Integer> ipConnections;
    
    // IP请求频率统计
    private ConcurrentHashMap<String, SlidingWindow> ipRequestRates;
    
    // IP封禁列表
    private ConcurrentHashMap<String, Long> bannedIPs;
    
    // URL路径请求统计
    private ConcurrentHashMap<String, SlidingWindow> pathRequestRates;
    
    // 全局请求计数器
    private SlidingWindow globalRequestCounter;
    
    // 黑名单
    private Set<String> blacklist;
    
    // 白名单
    private Set<String> whitelist;
    
    // 被屏蔽的User-Agent
    private Set<String> blockedUserAgents;
    
    // URL路径限制规则
    private Map<String, Integer> pathLimits;
    
    private DefenseWall() {
        ipConnections = new ConcurrentHashMap<>();
        ipRequestRates = new ConcurrentHashMap<>();
        bannedIPs = new ConcurrentHashMap<>();
        pathRequestRates = new ConcurrentHashMap<>();
        blacklist = new ConcurrentHashSet<>();
        whitelist = new ConcurrentHashSet<>();
        blockedUserAgents = new ConcurrentHashSet<>();
        pathLimits = new ConcurrentHashMap<>();
        globalRequestCounter = new SlidingWindow(1000); // 1秒窗口
    }
    
    public static DefenseWall getInstance() {
        if (instance == null) {
            synchronized (DefenseWall.class) {
                if (instance == null) {
                    instance = new DefenseWall();
                }
            }
        }
        return instance;
    }
    
    public void init(ServerConfig config) {
        this.config = config;
        
        // 清理过期封禁的定时任务
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::cleanupBannedIPs, 60, 60, TimeUnit.SECONDS);
        
        // 清理过期请求统计
        scheduler.scheduleAtFixedRate(this::cleanupOldStats, 30, 30, TimeUnit.SECONDS);
    }
    
    public boolean isAllowed(String ip) {
        // 检查白名单
        if (isWhitelisted(ip)) {
            return true;
        }
        
        // 检查黑名单
        if (isBlacklisted(ip)) {
            return false;
        }
        
        // 检查是否被封禁
        Long bannedUntil = bannedIPs.get(ip);
        if (bannedUntil != null && bannedUntil > System.currentTimeMillis()) {
            return false;
        } else if (bannedUntil != null) {
            bannedIPs.remove(ip);
        }
        
        // 检查连接数限制
        int connections = ipConnections.getOrDefault(ip, 0);
        if (connections >= config.getMaxConnectionsPerIp()) {
            banIP(ip, "Too many connections");
            return false;
        }
        
        return true;
    }
    
    public boolean checkRequest(String ip, String path, String userAgent) {
        // 检查User-Agent
        if (isUserAgentBlocked(userAgent)) {
            banIP(ip, "Blocked User-Agent: " + userAgent);
            return false;
        }
        
        // 检查全局请求速率
        if (config.getGlobalRateLimit() > 0) {
            if (globalRequestCounter.getRequestCount() >= config.getGlobalRateLimit()) {
                return false;
            }
            globalRequestCounter.addRequest();
        }
        
        // 检查IP请求速率
        SlidingWindow ipWindow = ipRequestRates.computeIfAbsent(ip, 
            k -> new SlidingWindow(1000));
        
        int ipRate = ipWindow.getRequestCount();
        if (ipRate >= config.getRateLimitPerIp()) {
            // CC攻击检测
            if (ipRate >= config.getCcAttackThreshold()) {
                banIP(ip, "CC Attack detected");
            } else {
                banIP(ip, "Rate limit exceeded");
            }
            return false;
        }
        ipWindow.addRequest();
        
        // 检查路径特定限制
        for (Map.Entry<String, Integer> entry : pathLimits.entrySet()) {
            if (path.startsWith(entry.getKey())) {
                SlidingWindow pathWindow = pathRequestRates.computeIfAbsent(ip + ":" + entry.getKey(),
                    k -> new SlidingWindow(1000));
                
                if (pathWindow.getRequestCount() >= entry.getValue()) {
                    banIP(ip, "Path rate limit exceeded: " + entry.getKey());
                    return false;
                }
                pathWindow.addRequest();
                break;
            }
        }
        
        return true;
    }
    
    public void incrementConnection(String ip) {
        ipConnections.merge(ip, 1, Integer::sum);
    }
    
    public void decrementConnection(String ip) {
        ipConnections.computeIfPresent(ip, (k, v) -> v > 1 ? v - 1 : null);
    }
    
    public void recordRequest(String ip, String path) {
        // 用于统计，已在checkRequest中处理
    }
    
    public void recordBlockedRequest(String ip) {
        banIP(ip, "Blocked request");
    }
    
    private void banIP(String ip, String reason) {
        long banUntil = System.currentTimeMillis() + (config.getBanDuration() * 1000L);
        bannedIPs.put(ip, banUntil);
        System.out.println("[DEFENSE] Banned IP: " + ip + " - Reason: " + reason);
    }
    
    public String getBlockResponse() {
        int statusCode = config.getBlockStatusCode();
        return "HTTP/1.1 " + statusCode + " Too Many Requests\r\n" +
               "Content-Type: text/html\r\n" +
               "Retry-After: " + config.getBanDuration() + "\r\n\r\n" +
               "<h1>" + statusCode + " Too Many Requests</h1>" +
               "<p>You have been rate limited by Achac Defense Wall.</p>";
    }
    
    public void addToBlacklist(String ip) {
        blacklist.add(ip);
    }
    
    public void addToWhitelist(String ip) {
        whitelist.add(ip);
    }
    
    public void addBlockedUserAgent(String ua) {
        blockedUserAgents.add(ua.toLowerCase());
    }
    
    public void addPathLimit(String path, int rate) {
        pathLimits.put(path, rate);
    }
    
    private boolean isWhitelisted(String ip) {
        for (String white : whitelist) {
            if (white.endsWith("/24")) {
                String prefix = white.substring(0, white.indexOf("/"));
                if (ip.startsWith(prefix.substring(0, prefix.lastIndexOf(".")))) {
                    return true;
                }
            } else if (ip.equals(white)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isBlacklisted(String ip) {
        return blacklist.contains(ip);
    }
    
    private boolean isUserAgentBlocked(String userAgent) {
        if (userAgent == null) return false;
        String uaLower = userAgent.toLowerCase();
        for (String blocked : blockedUserAgents) {
            if (uaLower.contains(blocked)) {
                return true;
            }
        }
        return false;
    }
    
    private void cleanupBannedIPs() {
        long now = System.currentTimeMillis();
        bannedIPs.entrySet().removeIf(entry -> entry.getValue() <= now);
    }
    
    private void cleanupOldStats() {
        // 清理旧的滑动窗口数据
        long now = System.currentTimeMillis();
        // 具体实现在SlidingWindow中处理
    }
    
    // 滑动窗口内部类
    private static class SlidingWindow {
        private final long windowSize;
        private final Queue<Long> timestamps;
        
        public SlidingWindow(long windowSize) {
            this.windowSize = windowSize;
            this.timestamps = new ConcurrentLinkedQueue<>();
        }
        
        public void addRequest() {
            long now = System.currentTimeMillis();
            timestamps.offer(now);
            cleanup(now);
        }
        
        public int getRequestCount() {
            long now = System.currentTimeMillis();
            cleanup(now);
            return timestamps.size();
        }
        
        private void cleanup(long now) {
            while (!timestamps.isEmpty() && (now - timestamps.peek()) > windowSize) {
                timestamps.poll();
            }
        }
    }
    
    private static class ConcurrentHashSet<E> extends AbstractSet<E> {
        private final ConcurrentHashMap<E, Boolean> map = new ConcurrentHashMap<>();
        
        public boolean add(E e) {
            return map.putIfAbsent(e, Boolean.TRUE) == null;
        }
        
        public boolean remove(Object o) {
            return map.remove(o) != null;
        }
        
        public boolean contains(Object o) {
            return map.containsKey(o);
        }
        
        public Iterator<E> iterator() {
            return map.keySet().iterator();
        }
        
        public int size() {
            return map.size();
        }
    }
}