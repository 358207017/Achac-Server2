package security;

import java.util.concurrent.*;
import java.util.*;

public class RateLimiter {
    private final int maxRequests;
    private final long windowMs;
    private final ConcurrentHashMap<String, SlidingWindow> limits;
    
    public RateLimiter(int maxRequests, long windowMs) {
        this.maxRequests = maxRequests;
        this.windowMs = windowMs;
        this.limits = new ConcurrentHashMap<>();
    }
    
    public boolean allowRequest(String key) {
        SlidingWindow window = limits.computeIfAbsent(key, 
            k -> new SlidingWindow(windowMs));
        
        synchronized (window) {
            if (window.getCount() >= maxRequests) {
                return false;
            }
            window.addRequest();
            return true;
        }
    }
    
    public int getCurrentCount(String key) {
        SlidingWindow window = limits.get(key);
        return window != null ? window.getCount() : 0;
    }
    
    public void clear(String key) {
        limits.remove(key);
    }
    
    private static class SlidingWindow {
        private final long windowMs;
        private final Queue<Long> timestamps;
        
        public SlidingWindow(long windowMs) {
            this.windowMs = windowMs;
            this.timestamps = new ConcurrentLinkedQueue<>();
        }
        
        public void addRequest() {
            long now = System.currentTimeMillis();
            timestamps.offer(now);
            cleanup(now);
        }
        
        public int getCount() {
            long now = System.currentTimeMillis();
            cleanup(now);
            return timestamps.size();
        }
        
        private void cleanup(long now) {
            while (!timestamps.isEmpty() && (now - timestamps.peek()) > windowMs) {
                timestamps.poll();
            }
        }
    }
}