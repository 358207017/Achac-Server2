package security;

import java.util.*;
import java.util.regex.*;

public class RequestValidator {
    private static RequestValidator instance;
    
    // SQL注入模式
    private static final Pattern[] SQL_INJECTION_PATTERNS = {
        Pattern.compile("(?i)(\\bselect\\b.*\\bfrom\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(\\binsert\\b.*\\binto\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(\\bupdate\\b.*\\bset\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(\\bdelete\\b.*\\bfrom\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(\\bdrop\\b.*\\btable\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(\\bunion\\b.*\\bselect\\b)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(--|;|\\|\\|)"),
        Pattern.compile("('.*\\bor\\b.*'=.*')"),
        Pattern.compile("(\\bexec\\b.*\\bsp_\\w+)")
    };
    
    // XSS攻击模式
    private static final Pattern[] XSS_PATTERNS = {
        Pattern.compile("<script\\b[^>]*>(.*?)</script>", Pattern.CASE_INSENSITIVE),
        Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
        Pattern.compile("onload\\s*=", Pattern.CASE_INSENSITIVE),
        Pattern.compile("onerror\\s*=", Pattern.CASE_INSENSITIVE),
        Pattern.compile("onclick\\s*=", Pattern.CASE_INSENSITIVE),
        Pattern.compile("eval\\s*\\(", Pattern.CASE_INSENSITIVE),
        Pattern.compile("document\\.cookie", Pattern.CASE_INSENSITIVE)
    };
    
    // 路径遍历模式
    private static final Pattern PATH_TRAVERSAL = Pattern.compile("\\.\\./|\\.\\.\\\\");
    
    // 无效字符模式
    private static final Pattern INVALID_CHARS = Pattern.compile("[\\x00-\\x1F\\x7F]");
    
    private RequestValidator() {}
    
    public static RequestValidator getInstance() {
        if (instance == null) {
            synchronized (RequestValidator.class) {
                if (instance == null) {
                    instance = new RequestValidator();
                }
            }
        }
        return instance;
    }
    
    public ValidationResult validateRequest(String method, String path, String query, String body) {
        ValidationResult result = new ValidationResult();
        result.isValid = true;
        
        // 验证方法
        if (!isValidMethod(method)) {
            result.isValid = false;
            result.reason = "Invalid HTTP method";
            return result;
        }
        
        // 验证路径
        if (!isValidPath(path)) {
            result.isValid = false;
            result.reason = "Invalid path";
            return result;
        }
        
        // 检查路径遍历
        if (hasPathTraversal(path)) {
            result.isValid = false;
            result.reason = "Path traversal detected";
            return result;
        }
        
        // 检查SQL注入
        if (hasSQLInjection(path) || (query != null && hasSQLInjection(query))) {
            result.isValid = false;
            result.reason = "SQL injection detected";
            return result;
        }
        
        // 检查XSS
        if (hasXSS(path) || (query != null && hasXSS(query))) {
            result.isValid = false;
            result.reason = "XSS attack detected";
            return result;
        }
        
        // 检查请求体
        if (body != null && !isValidBody(body)) {
            result.isValid = false;
            result.reason = "Invalid request body";
            return result;
        }
        
        return result;
    }
    
    private boolean isValidMethod(String method) {
        String[] validMethods = {"GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS"};
        for (String valid : validMethods) {
            if (valid.equals(method)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isValidPath(String path) {
        if (path == null || path.isEmpty()) {
            return false;
        }
        
        // 检查路径长度
        if (path.length() > 2048) {
            return false;
        }
        
        // 检查无效字符
        if (INVALID_CHARS.matcher(path).find()) {
            return false;
        }
        
        // 检查只允许的字符
        return path.matches("^[\\w\\-/%.~]*$");
    }
    
    private boolean hasPathTraversal(String path) {
        return PATH_TRAVERSAL.matcher(path).find();
    }
    
    private boolean hasSQLInjection(String input) {
        if (input == null) return false;
        
        for (Pattern pattern : SQL_INJECTION_PATTERNS) {
            if (pattern.matcher(input).find()) {
                return true;
            }
        }
        return false;
    }
    
    private boolean hasXSS(String input) {
        if (input == null) return false;
        
        for (Pattern pattern : XSS_PATTERNS) {
            if (pattern.matcher(input).find()) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isValidBody(String body) {
        // 检查请求体大小（最大10MB）
        if (body.length() > 10 * 1024 * 1024) {
            return false;
        }
        
        // 检查是否包含空字节
        if (body.indexOf('\0') != -1) {
            return false;
        }
        
        return true;
    }
    
    public String sanitizeInput(String input) {
        if (input == null) return null;
        
        // HTML转义
        String sanitized = input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#x27;")
            .replace("/", "&#x2F;");
        
        return sanitized;
    }
    
    public static class ValidationResult {
        public boolean isValid;
        public String reason;
        
        @Override
        public String toString() {
            return isValid ? "Valid" : "Invalid: " + reason;
        }
    }
}