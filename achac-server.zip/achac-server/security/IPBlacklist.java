package security;

import java.util.concurrent.*;
import java.util.regex.*;

public class IPBlacklist {
    private static IPBlacklist instance;
    private ConcurrentHashMap<String, Long> blacklist;
    private ConcurrentHashMap<String, Pattern> cidrPatterns;
    private ScheduledExecutorService cleanupScheduler;
    
    private IPBlacklist() {
        blacklist = new ConcurrentHashMap<>();
        cidrPatterns = new ConcurrentHashMap<>();
        cleanupScheduler = Executors.newSingleThreadScheduledExecutor();
        
        // 每小时清理一次过期条目
        cleanupScheduler.scheduleAtFixedRate(this::cleanup, 1, 1, TimeUnit.HOURS);
    }
    
    public static IPBlacklist getInstance() {
        if (instance == null) {
            synchronized (IPBlacklist.class) {
                if (instance == null) {
                    instance = new IPBlacklist();
                }
            }
        }
        return instance;
    }
    
    public void addIP(String ip, long durationSeconds) {
        long expireTime = System.currentTimeMillis() + (durationSeconds * 1000);
        blacklist.put(ip, expireTime);
        System.out.println("[IPBlacklist] Added IP: " + ip + " for " + durationSeconds + "s");
    }
    
    public void addCIDR(String cidr, long durationSeconds) {
        try {
            Pattern pattern = convertCIDRToPattern(cidr);
            cidrPatterns.put(cidr, pattern);
            System.out.println("[IPBlacklist] Added CIDR: " + cidr);
            
            // 可选：同时添加过期时间
            if (durationSeconds > 0) {
                ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
                scheduler.schedule(() -> {
                    cidrPatterns.remove(cidr);
                    System.out.println("[IPBlacklist] Removed CIDR: " + cidr);
                }, durationSeconds, TimeUnit.SECONDS);
            }
        } catch (Exception e) {
            System.err.println("Invalid CIDR format: " + cidr);
        }
    }
    
    public boolean isBlocked(String ip) {
        // 检查精确匹配
        Long expireTime = blacklist.get(ip);
        if (expireTime != null) {
            if (expireTime > System.currentTimeMillis()) {
                return true;
            } else {
                blacklist.remove(ip);
            }
        }
        
        // 检查CIDR匹配
        for (Pattern pattern : cidrPatterns.values()) {
            if (pattern.matcher(ip).matches()) {
                return true;
            }
        }
        
        return false;
    }
    
    public void removeIP(String ip) {
        blacklist.remove(ip);
        System.out.println("[IPBlacklist] Removed IP: " + ip);
    }
    
    public void clear() {
        blacklist.clear();
        cidrPatterns.clear();
        System.out.println("[IPBlacklist] Cleared all entries");
    }
    
    public int getSize() {
        return blacklist.size() + cidrPatterns.size();
    }
    
    private Pattern convertCIDRToPattern(String cidr) {
        String[] parts = cidr.split("/");
        String ip = parts[0];
        int prefixLength = Integer.parseInt(parts[1]);
        
        String[] octets = ip.split("\\.");
        int mask = 0xFFFFFFFF << (32 - prefixLength);
        
        StringBuilder pattern = new StringBuilder("^");
        for (int i = 0; i < 4; i++) {
            if (i > 0) pattern.append("\\.");
            int octet = Integer.parseInt(octets[i]);
            int remainingBits = Math.min(8, prefixLength - i * 8);
            if (remainingBits <= 0) {
                pattern.append("\\d+");
            } else if (remainingBits == 8) {
                pattern.append(octet);
            } else {
                int min = octet & (0xFF << (8 - remainingBits));
                int max = min | ((1 << (8 - remainingBits)) - 1);
                pattern.append("(").append(min).append("-").append(max).append(")");
            }
        }
        pattern.append("$");
        
        return Pattern.compile(pattern.toString());
    }
    
    private void cleanup() {
        long now = System.currentTimeMillis();
        blacklist.entrySet().removeIf(entry -> entry.getValue() <= now);
    }
    
    public void shutdown() {
        cleanupScheduler.shutdown();
    }
}