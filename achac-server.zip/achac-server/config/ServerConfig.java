package config;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;

public class ServerConfig {
    private int port = 8080;
    private String staticRoot = "./static";
    private int workerCount = 0;
    private int globalRateLimit = 10000;
    private int maxConnectionsPerIp = 100;
    private int rateLimitPerIp = 50;
    private int banDuration = 300;
    private int ccAttackThreshold = 200;
    private int blockStatusCode = 429;
    private boolean smartDetection = true;
    
    private static ServerConfig instance;
    
    public ServerConfig() {
        instance = this;
    }
    
    public static ServerConfig getInstance() {
        return instance;
    }
    
    public void loadConfig(String path) throws Exception {
        File configFile = new File(path);
        if (!configFile.exists()) {
            System.out.println("Config file not found: " + path + ", using defaults");
            return;
        }
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(configFile);
        
        NodeList defenseNodes = doc.getElementsByTagName("defense");
        if (defenseNodes.getLength() > 0) {
            Element defense = (Element) defenseNodes.item(0);
            globalRateLimit = Integer.parseInt(getTagValue(defense, "global-rate-limit"));
            maxConnectionsPerIp = Integer.parseInt(getTagValue(defense, "max-connections-per-ip"));
            rateLimitPerIp = Integer.parseInt(getTagValue(defense, "rate-limit-per-ip"));
            banDuration = Integer.parseInt(getTagValue(defense, "ban-duration"));
            ccAttackThreshold = Integer.parseInt(getTagValue(defense, "cc-attack-threshold"));
            blockStatusCode = Integer.parseInt(getTagValue(defense, "block-status-code"));
            smartDetection = Boolean.parseBoolean(getTagValue(defense, "smart-detection"));
        }
    }
    
    private String getTagValue(Element parent, String tagName) {
        NodeList list = parent.getElementsByTagName(tagName);
        if (list.getLength() > 0) {
            return list.item(0).getTextContent();
        }
        return "";
    }
    
    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }
    public String getStaticRoot() { return staticRoot; }
    public void setStaticRoot(String staticRoot) { this.staticRoot = staticRoot; }
    public int getWorkerCount() { return workerCount; }
    public void setWorkerCount(int workerCount) { this.workerCount = workerCount; }
    public int getGlobalRateLimit() { return globalRateLimit; }
    public int getMaxConnectionsPerIp() { return maxConnectionsPerIp; }
    public int getRateLimitPerIp() { return rateLimitPerIp; }
    public int getBanDuration() { return banDuration; }
    public int getCcAttackThreshold() { return ccAttackThreshold; }
    public int getBlockStatusCode() { return blockStatusCode; }
    public boolean isSmartDetection() { return smartDetection; }
}