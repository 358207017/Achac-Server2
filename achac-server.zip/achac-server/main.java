import config.ServerConfig;
import core.EventLoop;
import core.Master;
import security.DefenseWall;
import java.io.*;
import java.nio.file.*;

public class main {
    private static final String VERSION = "Achac Server v1.0.0";
    private static Master master;
    private static DefenseWall defenseWall;
    
    public static void main(String[] args) {
        System.out.println(VERSION);
        System.out.println("Event-driven high-performance server");
        System.out.println("DOS/CC Defense Wall Enabled");
        System.out.println("=====================================");
        System.out.println("Working Directory: " + System.getProperty("user.dir"));
        System.out.println("=====================================");
        
        try {
            // 加载配置
            ServerConfig config = new ServerConfig();
            String configPath = System.getProperty("config.file", "doscc.xml");
            config.loadConfig(configPath);
            
            // 设置静态文件根目录
            String staticRoot = System.getProperty("static.root", "./static");
            config.setStaticRoot(staticRoot);
            
            // 确保静态文件目录存在
            Files.createDirectories(Paths.get(staticRoot));
            
            // 初始化防御墙
            defenseWall = DefenseWall.getInstance();
            defenseWall.init(config);
            System.out.println("✓ DOS/CC Defense Wall initialized");
            
            // 获取CPU核心数
            int availableProcessors = Runtime.getRuntime().availableProcessors();
            int workerCount = config.getWorkerCount() > 0 ? 
                            config.getWorkerCount() : availableProcessors;
            
            System.out.println("✓ System CPUs: " + availableProcessors);
            System.out.println("✓ Worker processes: " + workerCount);
            System.out.println("✓ Port: " + config.getPort());
            System.out.println("✓ Static root: " + config.getStaticRoot());
            System.out.println("=====================================");
            
            // 创建并启动Master进程
            master = new Master(workerCount, config, defenseWall);
            master.start();
            
            // 添加关闭钩子
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("\nShutting down Achac Server...");
                if (master != null) {
                    master.stop();
                }
                System.out.println("✓ Server stopped");
            }));
            
            System.out.println("\n✓ Achac Server started successfully!");
            System.out.println("✓ Listening on http://localhost:" + config.getPort());
            System.out.println("✓ Press Ctrl+C to stop");
            System.out.println("\n=====================================");
            System.out.println("Test commands:");
            System.out.println("  curl http://localhost:" + config.getPort() + "/");
            System.out.println("  curl http://localhost:" + config.getPort() + "/index.html");
            System.out.println("=====================================");
            
            // 主线程等待
            Thread.currentThread().join();
            
        } catch (Exception e) {
            System.err.println("Failed to start Achac Server: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}