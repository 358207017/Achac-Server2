# Achac Server - High Performance Event-Driven Web Server

## Project Overview

Achac is a high-performance, event-driven web server built with asynchronous non-blocking architecture, following the design philosophy similar to Nginx. It can easily support tens of thousands to hundreds of thousands of concurrent connections on a standard server.

## Core Features

### 1. Event-Driven Architecture
- Asynchronous, non-blocking event-driven model
- Master-Worker multi-process architecture
- Each worker process handles thousands of connections asynchronously
- No expensive thread creation/destruction/context switching overhead

### 2. DOS/CC Defense Wall
- **IP Rate Limiting**: Request frequency limits per IP
- **Connection Limits**: Maximum concurrent connections per IP
- **Global Rate Limiting**: Overall server request limits
- **Auto Ban**: Automatic IP banning when thresholds exceeded
- **Whitelist/Blacklist**: IP whitelist and blacklist support
- **CC Attack Detection**: Smart CC attack detection and mitigation

### 3. Static File Serving
- High-performance static file delivery
- Directory listing support
- MIME type recognition
- File caching mechanism
- Path traversal attack prevention

### 4. Reverse Proxy & Load Balancing
- Reverse proxy support
- Multiple load balancing algorithms (Round Robin, Least Connections, IP Hash)
- Backend health checking
- Automatic failover

### 5. Security Features
- HTTP request validation
- SQL injection prevention
- XSS attack prevention
- User-Agent filtering
- Path traversal protection

## Architecture
## Performance

### Benchmark Results
- **Concurrent Connections**: 50,000+
- **Requests Per Second**: 30,000+ (static files)
- **Response Time**: < 10ms average
- **Memory Usage**: ~50MB base + 2KB per connection

### Performance Features
- Zero-copy file sending
- Connection pooling
- Request/Response caching
- Efficient memory management

## Configuration

### DOS/CC Defense Configuration (doscc.xml)
```xml
<doscc-config>
    <defense>
        <global-rate-limit>10000</global-rate-limit>
        <max-connections-per-ip>100</max-connections-per-ip>
        <rate-limit-per-ip>50</rate-limit-per-ip>
        <ban-duration>300</ban-duration>
        <cc-attack-threshold>200</cc-attack-threshold>
    </defense>
</doscc-config>