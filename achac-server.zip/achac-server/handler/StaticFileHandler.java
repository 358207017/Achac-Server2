package handler;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import util.MimeTypeUtil;

public class StaticFileHandler {
    private static final int BUFFER_SIZE = 8192;
    private static final Map<String, byte[]> fileCache = new HashMap<>();
    private static final Map<String, Long> cacheTimestamps = new HashMap<>();
    private static final long CACHE_DURATION = 60000; // 60秒缓存
    
    public static byte[] serveStaticFile(String filePath, String staticRoot) throws IOException {
        // 安全检查
        if (filePath.contains("..")) {
            throw new SecurityException("Path traversal detected");
        }
        
        String fullPath = staticRoot + filePath;
        File file = new File(fullPath);
        
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filePath);
        }
        
        if (file.isDirectory()) {
            // 如果是目录，返回目录列表的HTML
            return generateDirectoryListing(filePath, file).getBytes();
        }
        
        // 检查缓存
        long lastModified = file.lastModified();
        String cacheKey = fullPath;
        
        if (isCacheValid(cacheKey, lastModified)) {
            return fileCache.get(cacheKey);
        }
        
        // 读取文件
        byte[] content = Files.readAllBytes(file.toPath());
        
        // 更新缓存
        updateCache(cacheKey, content, lastModified);
        
        return content;
    }
    
    private static String generateDirectoryListing(String requestPath, File directory) {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n");
        html.append("<html>\n<head>\n");
        html.append("<meta charset=\"UTF-8\">\n");
        html.append("<title>Index of ").append(requestPath).append("</title>\n");
        html.append("<style>\n");
        html.append("body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background: #f5f5f5; }\n");
        html.append(".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }\n");
        html.append("h1 { color: #333; border-bottom: 2px solid #0066cc; padding-bottom: 10px; }\n");
        html.append("ul { list-style: none; padding: 0; }\n");
        html.append("li { padding: 8px; border-bottom: 1px solid #eee; }\n");
        html.append("li:hover { background: #f9f9f9; }\n");
        html.append("a { text-decoration: none; color: #0066cc; }\n");
        html.append("a:hover { text-decoration: underline; }\n");
        html.append(".file-icon { display: inline-block; width: 20px; margin-right: 10px; }\n");
        html.append(".footer { margin-top: 20px; text-align: center; color: #999; font-size: 12px; }\n");
        html.append("</style>\n");
        html.append("</head>\n<body>\n");
        html.append("<div class=\"container\">\n");
        html.append("<h1>📁 Index of ").append(requestPath).append("</h1>\n");
        html.append("<ul>\n");
        
        // 添加父目录链接
        if (!requestPath.equals("/")) {
            String parentPath = requestPath.substring(0, requestPath.lastIndexOf("/"));
            if (parentPath.isEmpty()) parentPath = "/";
            html.append("<li><a href=\"").append(parentPath).append("\">📂 ../</a></li>\n");
        }
        
        // 列出目录内容
        File[] files = directory.listFiles();
        if (files != null) {
            Arrays.sort(files, (f1, f2) -> {
                if (f1.isDirectory() && !f2.isDirectory()) return -1;
                if (!f1.isDirectory() && f2.isDirectory()) return 1;
                return f1.getName().compareToIgnoreCase(f2.getName());
            });
            
            for (File file : files) {
                String name = file.getName();
                String displayPath = requestPath + (requestPath.endsWith("/") ? "" : "/") + name;
                if (file.isDirectory()) {
                    html.append("<li><a href=\"").append(displayPath).append("/\">📂 ").append(name).append("/</a></li>\n");
                } else {
                    String size = formatFileSize(file.length());
                    html.append("<li><a href=\"").append(displayPath).append("\">📄 ").append(name).append("</a> <span style=\"color:#999;float:right\">").append(size).append("</span></li>\n");
                }
            }
        }
        
        html.append("</ul>\n");
        html.append("<div class=\"footer\">\n");
        html.append("<p>Achac Server - High Performance Event-Driven Server</p>\n");
        html.append("</div>\n");
        html.append("</div>\n");
        html.append("</body>\n</html>");
        
        return html.toString();
    }
    
    private static String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024));
        return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
    }
    
    private static boolean isCacheValid(String key, long lastModified) {
        if (!fileCache.containsKey(key)) return false;
        Long cachedTime = cacheTimestamps.get(key);
        if (cachedTime == null) return false;
        
        // 检查文件是否被修改
        if (lastModified > cachedTime) return false;
        
        // 检查缓存是否过期
        return (System.currentTimeMillis() - cachedTime) < CACHE_DURATION;
    }
    
    private static void updateCache(String key, byte[] content, long lastModified) {
        // 限制缓存大小（最多100个文件）
        if (fileCache.size() > 100) {
            String firstKey = fileCache.keySet().iterator().next();
            fileCache.remove(firstKey);
            cacheTimestamps.remove(firstKey);
        }
        
        fileCache.put(key, content);
        cacheTimestamps.put(key, lastModified);
    }
    
    public static void clearCache() {
        fileCache.clear();
        cacheTimestamps.clear();
        System.out.println("[StaticFileHandler] Cache cleared");
    }
}