package handler;

import loadbalance.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class ReverseProxyHandler {
    private static LoadBalancer loadBalancer;
    
    static {
        // 默认使用轮询算法
        loadBalancer = new RoundRobin();
        
        // 示例：添加后端服务器
        // loadBalancer.addServer(new BackendServer("localhost", 3000));
        // loadBalancer.addServer(new BackendServer("localhost", 3001));
    }
    
    public static String handleProxy(String method, String path, String clientIp, 
                                      String requestBody, Map<String, String> headers) {
        
        BackendServer server = loadBalancer.getNextServer(clientIp, path);
        
        if (server == null) {
            return "HTTP/1.1 503 Service Unavailable\r\n" +
                   "Content-Type: text/html\r\n\r\n" +
                   "<h1>503 Service Unavailable</h1>" +
                   "<p>No healthy backends available</p>";
        }
        
        server.incrementConnections();
        
        try {
            String response = forwardRequest(server, method, path, requestBody, headers);
            return response;
        } catch (Exception e) {
            server.setHealthy(false);
            return "HTTP/1.1 502 Bad Gateway\r\n" +
                   "Content-Type: text/html\r\n\r\n" +
                   "<h1>502 Bad Gateway</h1>" +
                   "<p>" + e.getMessage() + "</p>";
        } finally {
            server.decrementConnections();
        }
    }
    
    private static String forwardRequest(BackendServer server, String method, 
                                         String path, String requestBody, 
                                         Map<String, String> headers) throws Exception {
        
        URL url = new URL(server.getUrl() + path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(10000);
        
        // 转发头信息
        for (Map.Entry<String, String> header : headers.entrySet()) {
            connection.setRequestProperty(header.getKey(), header.getValue());
        }
        
        // 添加代理头
        connection.setRequestProperty("X-Forwarded-For", headers.getOrDefault("X-Forwarded-For", ""));
        connection.setRequestProperty("X-Proxy-By", "Achac/1.0");
        
        // 发送请求体
        if (requestBody != null && !requestBody.isEmpty()) {
            connection.setDoOutput(true);
            try (OutputStream os = connection.getOutputStream()) {
                os.write(requestBody.getBytes());
                os.flush();
            }
        }
        
        // 读取响应
        int responseCode = connection.getResponseCode();
        StringBuilder response = new StringBuilder();
        
        response.append("HTTP/1.1 ").append(responseCode).append(" ").append(connection.getResponseMessage()).append("\r\n");
        
        // 转发响应头
        Map<String, List<String>> responseHeaders = connection.getHeaderFields();
        for (Map.Entry<String, List<String>> entry : responseHeaders.entrySet()) {
            if (entry.getKey() != null && !entry.getKey().equals("Transfer-Encoding")) {
                for (String value : entry.getValue()) {
                    response.append(entry.getKey()).append(": ").append(value).append("\r\n");
                }
            }
        }
        
        response.append("\r\n");
        
        // 读取响应体
        try (InputStream is = connection.getInputStream()) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line).append("\n");
            }
        } catch (IOException e) {
            // 尝试读取错误流
            try (InputStream es = connection.getErrorStream()) {
                if (es != null) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(es));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line).append("\n");
                    }
                }
            }
        }
        
        connection.disconnect();
        return response.toString();
    }
    
    public static void addBackendServer(String host, int port) {
        loadBalancer.addServer(new BackendServer(host, port));
    }
    
    public static void addBackendServer(String host, int port, int weight) {
        loadBalancer.addServer(new BackendServer(host, port, weight));
    }
    
    public static void removeBackendServer(String host, int port) {
        loadBalancer.removeServer(host, port);
    }
    
    public static void performHealthCheck() {
        loadBalancer.healthCheck();
    }
}