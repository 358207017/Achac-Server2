package handler;

import security.DefenseWall;
import util.MimeTypeUtil;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class RequestHandler {
    
    public static String handle(String method, String path, String staticRoot, 
                                DefenseWall defenseWall, String clientIp) {
        
        if (!method.equals("GET")) {
            return buildResponse(405, "Method Not Allowed", 
                   "<h1>405 Method Not Allowed</h1><p>Only GET method is supported</p>");
        }
        
        if (path.contains("..")) {
            if (defenseWall != null) defenseWall.recordBlockedRequest(clientIp);
            return buildResponse(403, "Forbidden", 
                   "<h1>403 Forbidden</h1><p>Invalid path</p>");
        }
        
        if (path.equals("/")) {
            path = "/index.html";
        }
        
        String filePath = staticRoot + path;
        File file = new File(filePath);
        
        if (!file.exists() || !file.canRead()) {
            return buildResponse(404, "Not Found", 
                   "<h1>404 Not Found</h1><p>The requested resource was not found</p>");
        }
        
        if (file.isDirectory()) {
            return listDirectory(path, file);
        }
        
        try {
            byte[] content = Files.readAllBytes(file.toPath());
            String mimeType = MimeTypeUtil.getMimeType(filePath);
            return buildResponseWithBody(200, "OK", mimeType, content);
        } catch (IOException e) {
            return buildResponse(500, "Internal Server Error", 
                   "<h1>500 Internal Server Error</h1><p>" + e.getMessage() + "</p>");
        }
    }
    
    private static String listDirectory(String path, File directory) {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html><head><title>Index of ").append(path).append("</title>");
        html.append("<style>body{font-family:monospace;margin:40px} a{color:#0066cc}</style>");
        html.append("</head><body><h1>Index of ").append(path).append("</h1><hr><ul>");
        
        if (!path.equals("/")) {
            String parentPath = path.substring(0, path.lastIndexOf("/"));
            if (parentPath.isEmpty()) parentPath = "/";
            html.append("<li><a href=\"").append(parentPath).append("\">../</a></li>");
        }
        
        File[] files = directory.listFiles();
        if (files != null) {
            Arrays.sort(files);
            for (File file : files) {
                String name = file.getName();
                String filePath = path + (path.endsWith("/") ? "" : "/") + name;
                if (file.isDirectory()) name += "/";
                html.append("<li><a href=\"").append(filePath).append("\">").append(name).append("</a></li>");
            }
        }
        
        html.append("</ul><hr><p><em>Achac Server</em></p></body></html>");
        return buildResponse(200, "OK", html.toString());
    }
    
    private static String buildResponse(int statusCode, String statusText, String body) {
        return buildResponseWithBody(statusCode, statusText, "text/html", body.getBytes());
    }
    
    private static String buildResponseWithBody(int statusCode, String statusText, 
                                                  String contentType, byte[] body) {
        StringBuilder response = new StringBuilder();
        response.append("HTTP/1.1 ").append(statusCode).append(" ").append(statusText).append("\r\n");
        response.append("Server: Achac/1.0.0\r\n");
        response.append("Content-Type: ").append(contentType).append("\r\n");
        response.append("Content-Length: ").append(body.length).append("\r\n");
        response.append("Connection: close\r\n\r\n");
        return response.toString() + new String(body);
    }
}